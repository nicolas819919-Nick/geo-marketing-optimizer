# 官方依据与更新入口

本技能的机制边界依据以下实际读取的官方页面。核查日期：2026-11-05（Asia/Shanghai）。这些来源不公开所有排序权重，也不证明任何跨平台收益倍数。

| 官方页面 | 支持本技能的范围 | 不应外推的结论 |
|---|---|---|
| [Google：AI features and your website](https://developers.google.com/search/docs/appearance/ai-features) | AI Search 仍依赖 SEO 基础；可能使用 query fan-out；文本可访问；无需特殊 AI 文件/schema；展示不保证 | 不能当作所有 AI 平台的内部架构或收录保证；其报告说明需结合较新指南核查 |
| [Google：Optimizing your website for generative AI features](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide) | 以人为本、原创经验与价值；不必固定字数或穷举长尾；无 AI 特殊 schema；不把 llms.txt 当 Google 排名工具；当前报告功能入口 | 针对 Google，不能推定其他系统同样处理文件、报告或引用 |
| [Google：Creating helpful, reliable, people-first content](https://developers.google.com/search/docs/fundamentals/creating-helpful-content) | 清晰来源、作者背景、真实经验、避免事实错误；不能只改日期冒充更新 | 不能把 E-E-A-T 当单一可量化排名因子，不能推出“权威来源 ×20” |
| [OpenAI：Overview of OpenAI Crawlers](https://developers.openai.com/api/docs/bots) | OAI-SearchBot、GPTBot、ChatGPT-User 用途不同；搜索与训练设置独立 | 允许访问不等于被引用；不能建议为搜索默认放开训练抓取 |
| [OpenAI API：Web search](https://developers.openai.com/api/docs/guides/tools-web-search/) | 搜索是工具能力，可选调用；实时与缓存/索引访问可配置；工具 sources 与最终引用不同 | API 选项不等于所有消费者 AI 产品的实现 |

Google 较新指南在本次核查时已介绍 Search Console 的 Generative AI performance report；不同页面与账户功能可能存在时间差。实施时核对最新官方指南和账户，而不是固定声称“没有 AI 专项报告”。

ChatGPT Search 帮助与介绍页本次受 JS/cookie 访问限制，未以未读取正文支持结论。Perplexity、Gemini 等平台的详细内部权重也没有在本技能中假定。

## 更新原则

- 涉及爬虫权限、结构化数据资格、报告或平台新功能时，重新核查原始官方文档。
- 新增研究数据时，保留原始出处、平台/版本、市场、样本、时间、测量定义及局限。实验结果不写成普遍增长承诺。
- 无出处的“央媒引用 20 倍”“结构化引用 2.3 倍”等，不作为本技能的规则或对外卖点。
- 维护产品事实库与第三方证据时，更新适用型号/地区/版本，不只刷新日期。
